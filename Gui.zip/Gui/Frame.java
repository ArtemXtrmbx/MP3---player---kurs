package Gui;

import java.awt.event.InputEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javazoom.jlgui.basicplayer.BasicController;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerEvent;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import javazoom.jlgui.basicplayer.BasicPlayerListener;

public class Frame extends javax.swing.JFrame implements BasicPlayerListener {

    

    public Frame() throws SocketException, UnknownHostException, IOException {
        
        Song = new PlayableSonInfo();
        Song.Player = new BasicPlayer();
        Song.PlayerControl =(BasicController)Song.Player;
        Song.Player.addBasicPlayerListener(this);
        Song.Gain = 0.1;
        socet = new DatagramSocket();
        ResSocket = new DatagramSocket(26);
        address = InetAddress.getByName("172.20.10.4");
        FileInputSocket = new ServerSocket(28);
        
        initComponents();
        PlaylistModule = (DefaultListModel) jList1.getModel();
       
        int GainInt = GainSlider.getValue();
       double NewGain = (double)GainInt /(double)1000;
       Song.Gain = NewGain;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuUpperPart = new javax.swing.JPanel();
        RemoveSong = new javax.swing.JButton();
        SavePlaylist = new javax.swing.JButton();
        OpenPlaylist = new javax.swing.JButton();
        AddSong = new javax.swing.JButton();
        MenuLowerPart = new javax.swing.JPanel();
        NextSong = new javax.swing.JButton();
        PreviousSong = new javax.swing.JButton();
        PlayPauseBnt = new javax.swing.JToggleButton();
        SongTimeline = new javax.swing.JSlider();
        RandomPlaylistChoose = new javax.swing.JToggleButton();
        PlaylistFrame = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        GainSlider = new javax.swing.JSlider();
        MuteBnt = new javax.swing.JToggleButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Player");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RemoveSong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/минус.png"))); // NOI18N
        RemoveSong.setToolTipText("Удалить песню");
        RemoveSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveSongActionPerformed(evt);
            }
        });

        SavePlaylist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/скачать.png"))); // NOI18N
        SavePlaylist.setToolTipText("Сохранить ");
        SavePlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SavePlaylistActionPerformed(evt);
            }
        });

        OpenPlaylist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/загрузить.png"))); // NOI18N
        OpenPlaylist.setToolTipText("Открыть");
        OpenPlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpenPlaylistActionPerformed(evt);
            }
        });

        AddSong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/добавить.png"))); // NOI18N
        AddSong.setToolTipText("Добавить песню");
        AddSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSongActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MenuUpperPartLayout = new javax.swing.GroupLayout(MenuUpperPart);
        MenuUpperPart.setLayout(MenuUpperPartLayout);
        MenuUpperPartLayout.setHorizontalGroup(
            MenuUpperPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, MenuUpperPartLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(SavePlaylist)
                .addGap(18, 18, 18)
                .addComponent(OpenPlaylist)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 279, Short.MAX_VALUE)
                .addComponent(RemoveSong)
                .addGap(18, 18, 18)
                .addComponent(AddSong)
                .addGap(15, 15, 15))
        );
        MenuUpperPartLayout.setVerticalGroup(
            MenuUpperPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuUpperPartLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(MenuUpperPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(OpenPlaylist)
                    .addComponent(AddSong)
                    .addComponent(RemoveSong)
                    .addComponent(SavePlaylist))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        OpenPlaylist.getAccessibleContext().setAccessibleDescription("");

        getContentPane().add(MenuUpperPart, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 48));

        NextSong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Вперёд.png"))); // NOI18N
        NextSong.setToolTipText("Вперёд");
        NextSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextSongActionPerformed(evt);
            }
        });

        PreviousSong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Назад.png"))); // NOI18N
        PreviousSong.setToolTipText("Назад");
        PreviousSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreviousSongActionPerformed(evt);
            }
        });

        PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Играть.png"))); // NOI18N
        PlayPauseBnt.setToolTipText("Воспроизведение / Пауза");
        PlayPauseBnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayPauseBntActionPerformed(evt);
            }
        });

        SongTimeline.setMaximum(1000);
        SongTimeline.setValue(0);
        SongTimeline.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                SongTimelineStateChanged(evt);
            }
        });

        RandomPlaylistChoose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/перемешать.png"))); // NOI18N
        RandomPlaylistChoose.setToolTipText("Случайное воспроизведение");
        RandomPlaylistChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RandomPlaylistChooseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MenuLowerPartLayout = new javax.swing.GroupLayout(MenuLowerPart);
        MenuLowerPart.setLayout(MenuLowerPartLayout);
        MenuLowerPartLayout.setHorizontalGroup(
            MenuLowerPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuLowerPartLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(MenuLowerPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SongTimeline, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuLowerPartLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(PreviousSong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PlayPauseBnt, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(NextSong, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addComponent(RandomPlaylistChoose, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        MenuLowerPartLayout.setVerticalGroup(
            MenuLowerPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuLowerPartLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SongTimeline, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(MenuLowerPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RandomPlaylistChoose, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NextSong)
                    .addComponent(PlayPauseBnt)
                    .addComponent(PreviousSong))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        getContentPane().add(MenuLowerPart, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 436, 470, 150));

        jList1.setFont(new java.awt.Font("Arial Black", 0, 13)); // NOI18N
        jList1.setModel(new DefaultListModel ());
        jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jList1.setDragEnabled(true);
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        javax.swing.GroupLayout PlaylistFrameLayout = new javax.swing.GroupLayout(PlaylistFrame);
        PlaylistFrame.setLayout(PlaylistFrameLayout);
        PlaylistFrameLayout.setHorizontalGroup(
            PlaylistFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PlaylistFrameLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
                .addContainerGap())
        );
        PlaylistFrameLayout.setVerticalGroup(
            PlaylistFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
        );

        getContentPane().add(PlaylistFrame, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 66, 418, -1));

        GainSlider.setMaximum(1000);
        GainSlider.setOrientation(javax.swing.JSlider.VERTICAL);
        GainSlider.setToolTipText("");
        GainSlider.setValue(10);
        GainSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                GainSliderStateChanged(evt);
            }
        });
        getContentPane().add(GainSlider, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 20, 220));

        MuteBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Звук.png"))); // NOI18N
        MuteBnt.setToolTipText("Включить / Выключить звук");
        MuteBnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MuteBntActionPerformed(evt);
            }
        });
        getContentPane().add(MuteBnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 360, 40, -1));
        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SavePlaylistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SavePlaylistActionPerformed
OpenDialogBox odb     = new OpenDialogBox();
        String FileName       = odb.DialogSave("bin") + ".bin";
        ArrayList<String> arr = new ArrayList<String>();
        
        try 
        {
            FileOutputStream fos   = new FileOutputStream(FileName);
            BufferedOutputStream bis = new BufferedOutputStream(fos);
            ObjectOutputStream oos = new ObjectOutputStream(bis);
            
            for (int i = 0; i < PlaylistModule.size(); i++)
            {
                
                arr.add((String) PlaylistModule.getElementAt(i));
            }
            
            oos.writeObject(arr);
            oos.close();
        } 
        catch (FileNotFoundException ex) 
        {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_SavePlaylistActionPerformed

    void PlayNextSong() throws IOException{
    int nextIndex = 0;
        if(PlaylistModule.getSize()>0){
            if(RandomPlaylistChoose.isSelected()){
               String SongName = GetRandomSong();
               PlaySong(SongName);
                PlayPauseBnt.setSelected(true);
                PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
               return;
            }
                
            for(int i = 0; i < PlaylistModule.getSize(); i++){
                if(Song.Name.equals(PlaylistModule.get(i))){
                    nextIndex = i + 1;
                    break;
                }
            }
            if(nextIndex <= PlaylistModule.getSize() -1){
            jList1.setSelectedIndex(nextIndex);
                try {
                    PlayPauseBnt.setSelected(true);
                    PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
                    PlaySong(jList1.getSelectedValue());
                } catch (IOException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    private void NextSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextSongActionPerformed
        try {
            PlayNextSong();
        } catch (IOException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_NextSongActionPerformed

    private void PlayPauseBntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayPauseBntActionPerformed
        if(PlayPauseBnt.isSelected()){
            PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
          
             String   SongName = jList1.getSelectedValue();
             if(SongName == null && RandomPlaylistChoose.isSelected())
                 SongName = GetRandomSong();
             
            if(SongName != null && !SongName.equals(Song.Name)){
                try {
                    PlaySong(SongName);
            } catch (IOException ex) {
                Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
            if (SongName != null && SongName.equals(Song.Name)) {
    try {
        Song.PlayerControl.resume();
    } catch (BasicPlayerException ex) {
        Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
    }
} else {
    JOptionPane.showMessageDialog(this, "Пожалуйста, выберите песню для воспроизведения", "Ошибка", JOptionPane.ERROR_MESSAGE);
    PlayPauseBnt.setSelected(false); //сбрасываем состояние кнопки
    PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Играть.png")));
                try {
                    Song.PlayerControl.pause();
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
}
        }
         else{
                PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Играть.png")));
                try {
                    Song.PlayerControl.pause();
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }//GEN-LAST:event_PlayPauseBntActionPerformed

    private void AddSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSongActionPerformed
        String buf = "AddSong";
        byte[] message = buf.getBytes();
        DatagramPacket packet = new DatagramPacket(message, message.length, address, 17);
        try {
            socet.send(packet);
        } catch (IOException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
        byte[] buffer = new byte[8196];
        DatagramPacket request = new DatagramPacket(buffer, buffer.length);
        String Message = "";
        try {
            ResSocket.receive(request);
             Message =  new String(request.getData(), 0, request.getLength());
        } catch (IOException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
        String[] SongsList = Message.split("~");
        
        SelectFrame AddSongs = new SelectFrame();
        AddSongs.setParentFrame(this);
        AddSongs.setSongsInList(SongsList);
        AddSongs.setVisible(true);
        AddSongs.isVisible();
        this.setVisible(false);
    }//GEN-LAST:event_AddSongActionPerformed
    
    private void MuteBntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MuteBntActionPerformed
        if(MuteBnt.isSelected()){
                Gain = GainSlider.getValue();
                GainSlider.setValue(0);
                MuteBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Без_звука.png")));
            }
            else{
                MuteBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Звук.png")));
                GainSlider.setValue(Gain);
            }
    }//GEN-LAST:event_MuteBntActionPerformed

    private void RemoveSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveSongActionPerformed
        int index = jList1.getSelectedIndex();
        if(index != -1)
        {
           PlaylistModule.removeElementAt(index);
        }
    }//GEN-LAST:event_RemoveSongActionPerformed

    private void OpenPlaylistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpenPlaylistActionPerformed
OpenDialogBox odb      = new OpenDialogBox();
        String FileName        = odb.DialogSave("bin");
        
        if(FileName != null){
         ArrayList<String> arr = new ArrayList<String>();
        
        try
        {
            FileInputStream fis     = new FileInputStream(FileName);      
            BufferedInputStream bis = new BufferedInputStream(fis);
            ObjectInputStream ois   = new ObjectInputStream(bis);
            
            arr = (ArrayList<String>) ois.readObject();
            PlaylistModule.clear();
            for (int i = 0; i < arr.size(); i++)
                 PlaylistModule.addElement((String)arr.get(i));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }//GEN-LAST:event_OpenPlaylistActionPerformed

    private void GainSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_GainSliderStateChanged
       int GainInt = GainSlider.getValue();
    double NewGain = (double) GainInt / (double) 1000;
    Song.Gain = NewGain;
    try {
        Song.PlayerControl.setGain(NewGain);
    } catch (BasicPlayerException ex) {
        // Обработка исключения
        //Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
        // Дополнительные действия, например, вывод сообщения об ошибке или возвращение к предыдущему значению усиления
        JOptionPane.showMessageDialog(this, "Ошибка при установке усиления(сначала запустите песню): " + ex.getMessage(), "Ошибка", JOptionPane.ERROR_MESSAGE);
        // Возвращаем ползунок к предыдущему значению
        GainSlider.setValue((int) (Song.Gain * 1000));
    }
    }//GEN-LAST:event_GainSliderStateChanged

    private void PreviousSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreviousSongActionPerformed
        int nextIndex = 0;
        if(PlaylistModule.getSize()>0){
            
            if(RandomPlaylistChoose.isSelected()){
               String SongName = GetRandomSong();
                try {
                    PlaySong(SongName);
                } catch (IOException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
                PlayPauseBnt.setSelected(true);
                PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
               return;
            }
            
            for(int i = 0; i < PlaylistModule.getSize(); i++){
                if(Song.Name.equals(PlaylistModule.get(i))){
                    nextIndex = i - 1;
                    break;
                }
            }
            if(nextIndex > -1){
            jList1.setSelectedIndex(nextIndex);
                try {
                    PlayPauseBnt.setSelected(true);
                    PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
                    PlaySong(jList1.getSelectedValue());
                } catch (IOException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_PreviousSongActionPerformed

    private void SongTimelineStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_SongTimelineStateChanged
       if(SongTimeline.getValueIsAdjusting() == false){
            if(AutoJump == true){
                try {
                    AutoJump = false;
                    //DurationJump = true;

                    double sliderPos = SongTimeline.getValue()*1.0 / 1000;
                    long bytesToskip = (long) Math.round(((long) Song._Size) *sliderPos);
                    //CurSong.PlayerControl.pause();
                    Song.PlayerControl.seek(bytesToskip);
                    //CurSong.PlayerControl.resume();
                    Song.PlayerControl.setGain(Song.Gain);
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
       }
            else{
            AutoJump = true;
            _Jump = true;
            }
     
    }//GEN-LAST:event_SongTimelineStateChanged

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        if(evt.getModifiers() == InputEvent.BUTTON1_MASK && evt.getClickCount() == 2){
            if(PlayPauseBnt.isSelected()){
                try {
                    PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Играть.png")));
                    Song.PlayerControl.stop();
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{
             PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/пауза.png")));
             PlayPauseBnt.setSelected(true);
            }
            String SongName = jList1.getSelectedValue();
            try {
                PlaySong(SongName);
            } catch (IOException ex) {
                Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }//GEN-LAST:event_jList1MouseClicked

    private void RandomPlaylistChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RandomPlaylistChooseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RandomPlaylistChooseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Frame().setVisible(true);
                } catch (SocketException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnknownHostException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    @Override
    public void opened(Object o, Map map) {
        Song.PlayStatus = true;
        SongTimeline.setValue(0);
    }

    @Override 
    public void progress(int i, long l, byte[] bytes, Map map) {
        float progress = 1.0f;
      long bytesread =  (long) map.get("mp3.position.byte");
        if((bytesread>0) && (Song.duration > 0))
            progress = bytesread*1.0f/Song._Size*1.0f;
        
        long secondAmount = (long) (Song.duration * progress);
                if(Song.duration !=0){
                    if(_Jump == false){
                        SongTimeline.setValue((int) Math.round((secondAmount)*1000 / Song.duration));
                    }
                }
    }

    @Override
    public void stateUpdated(BasicPlayerEvent bpe) {
        
        int state = bpe.getCode();
        switch(state){
            case BasicPlayerEvent.PLAYING:{
                _Jump = false;
                break;
            }
            case BasicPlayerEvent.SEEKING:{
                _Jump = true;
                break;
            }
            case BasicPlayerEvent.EOM:{
                Song.PlayStatus = false;
                PlayPauseBnt.setSelected(false);
                PlayPauseBnt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/Играть.png")));
            try {
                PlayNextSong();
            } catch (IOException ex) {
                Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
            }
                break;
            }
        
        }
    }

    @Override
    public void setController(BasicController bc) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    String GetRandomSong(){
       while(true){
           int SongNum =  (int) (Math.random()*PlaylistModule.getSize());
           if(!PlaylistModule.get(SongNum).equals(Song.Name)){
               jList1.setSelectedIndex(SongNum);
               return (String) PlaylistModule.get(SongNum);
           }
       }
    
    }
    
    class PlayableSonInfo
    {
        String Name;
        byte[] _Data;
        long _Size;
        long duration;
        BasicController PlayerControl;
        BasicPlayer Player;
        double Gain;
        boolean PlayStatus;

    }
       class OpenDialogBox
   {
       String FileName;
       
       public String DialogSave(String NameFilter)
       {
            JFileChooser chooser           = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "bin", NameFilter);
            
            chooser.setFileFilter(filter);
            int returnVal = chooser.showSaveDialog(null);
            
            if(returnVal == JFileChooser.APPROVE_OPTION) 
            {
                FileName = chooser.getSelectedFile().getAbsolutePath();
            } 
            
            return FileName;
        }
    }
    
       void PlaySong(String SongName) throws IOException{
            try {
                Song.PlayerControl.stop();

                String buf = "PlaySong" + "~" + SongName;
                byte[] message = buf.getBytes();
                DatagramPacket packet = new DatagramPacket(message, message.length, address, 17);

                socet.send(packet);

                try {
                    Socket InSocket = FileInputSocket.accept();
                    DataInputStream Data = new DataInputStream(InSocket.getInputStream());
    
                    int FileSize = Data.readInt();
                    int FileTime = Data.readInt();
                    if (FileSize > 0){
                    byte[] FileContent = new byte[FileSize];
                    Data.readFully(FileContent, 0, FileSize);
                    Song.Name = SongName;
                    Song._Data = FileContent;
                    Song._Size = FileSize;
                    Song.duration = FileTime;
                    InSocket.close();
                    File Buffer = new File("Song.mp3");
                    FileOutputStream fos = new FileOutputStream(Buffer);
                    fos.write(Song._Data);
                    fos.close();
                    InputStream a = new FileInputStream(Buffer);
        
                    Song.PlayerControl.open(Buffer);
                    Song.PlayerControl.play();
                    Song.PlayerControl.setGain(Song.Gain);
                }
                } catch (IOException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                }
    } 
       
           boolean AutoJump = false;
    boolean _Jump = false;

    ServerSocket FileInputSocket;
    DatagramSocket socet, ResSocket;
    InetAddress  address;
    DefaultListModel PlaylistModule;
    PlayableSonInfo Song; 
    int Gain;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddSong;
    private javax.swing.JSlider GainSlider;
    private javax.swing.JPanel MenuLowerPart;
    private javax.swing.JPanel MenuUpperPart;
    private javax.swing.JToggleButton MuteBnt;
    private javax.swing.JButton NextSong;
    private javax.swing.JButton OpenPlaylist;
    private javax.swing.JToggleButton PlayPauseBnt;
    private javax.swing.JPanel PlaylistFrame;
    private javax.swing.JButton PreviousSong;
    private javax.swing.JToggleButton RandomPlaylistChoose;
    private javax.swing.JButton RemoveSong;
    private javax.swing.JButton SavePlaylist;
    private javax.swing.JSlider SongTimeline;
    private javax.swing.JList<String> jList1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
